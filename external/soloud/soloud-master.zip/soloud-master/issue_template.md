> Expected behavior:


> Actual behavior:


> Steps to reproduce the problem:


> SoLoud version, operating system, backend used, any other potentially useful information:


[//]: # ( You don't need to follow the above template if you do not want to; feel free to start from scratch. )
[//]: # ( Following the template leads to problem reports that are helpful to the developers. )
[//]: # ( ...yes, this weird syntax is how one writes comments in a markdown file )
