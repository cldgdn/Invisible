The contrib folder contains files that may be of use to some people
but are not maintained by the project itself. As such they may be
out of date. Pull requests are welcome.
 
Note that the licenses of the contrib files may also be out of line
with the SoLoud proper. You have been warned.